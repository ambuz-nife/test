package models

type View struct {
	Todos []Todo
}
